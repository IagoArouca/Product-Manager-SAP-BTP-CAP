sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("comdouradoproducts.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map